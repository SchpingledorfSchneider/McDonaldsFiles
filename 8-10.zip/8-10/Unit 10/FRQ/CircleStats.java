
public class CircleStats
{
    public CircleStats()
    {
    }    

    public double calcCircleCircumf(int diameter)
    {
        return (diameter  * Math.PI);
    }

    public double calcCircleCircumf(double radius)
    {
        return ((radius * 2) * Math.PI);
    }
    
}